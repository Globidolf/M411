package main;

/**
 * Generic Linked List with basic functionality
 * @author Silvan Pfister
 *
 * @param <T> Type of the values in the linked list
 */
public class LinkedList<T> {
	private Node<T> head;
	private int count;

	private Node<T> getNode(int index){
		if (index >= count) throw new IndexOutOfBoundsException();
		Node<T> cursor = head;
		while (index > 0){
			index--;
			cursor = cursor.getNext();
		}
		return cursor;
	}
	
	public int getCount() { return count; }
	
	public T get(int index){ return getNode(index).getValue(); }
	
	
	public void Insert(T item, int index){
		if (index == 0){
			head = new Node<T>(item, head);
		} else {
			Node<T> cursor = getNode(index-1);
			Node<T> next = new Node<T>(item, cursor != null ? cursor.getNext() : null);
			cursor.setNext(next);
		}
		count++;
	}
	
	public void Append(T item){
		Node<T> next = new Node<T>(item);
		if (head == null) head = next;
		else{
			Node<T> cursor = head;
			while(cursor.hasNext()) cursor = cursor.getNext();
			cursor.setNext(next);
		}
		count++;
	}
	
	public void Prepend(T item){ 
		head = new Node<T>(item, head); 
		count++;
	}
}
