package main;

import java.time.Duration;
import java.time.Instant;
import java.util.Random;

/**
 * Testklasse ohne fixen zweck
 * @author Silvan Pfister
 *
 */
public class Test {
	
	public static void main(String[] args) {
		
		Random rng = new Random();

		Integer[] base, arr;
		base = ArrEx.Instantiate(100000, Integer.class, rng::nextInt);
		
		arr = ArrEx.Duplicate(base, Integer.class);
		
		Instant tStart, tEnd;
		Duration dur;
		
		tStart = Instant.now();
		ArrEx.BubbleSort(arr);
		tEnd = Instant.now();
		dur = Duration.between(tStart, tEnd);
		
		Utility.WriteOutput("Bubblesort took " + dur.toMillis() + " ms.");
		//Utility.WriteOutput(ArrEx.AsString(arr));
		
		arr = ArrEx.Duplicate(base, Integer.class);
		
		tStart = Instant.now();
		ArrEx.QuickSort(arr);
		tEnd = Instant.now();
		dur = Duration.between(tStart, tEnd);
		
		Utility.WriteOutput("Quicksort took " + dur.toMillis() + " ms.");
		//Utility.WriteOutput(ArrEx.AsString(arr));
		
	}

}
