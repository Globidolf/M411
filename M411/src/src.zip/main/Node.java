package main;
/**
 * Generic Node with a next element and a value
 * @author Silvan Pfister
 *
 * @param <T> Type of the node value
 */
public class Node<T> {
	private T value;
	private Node<T> next;

	public Node(T value){ this.value = value; }
	
	public Node(T value, Node<T> next){
		this.value = value;
		this.next = next;
	}
	
	public T getValue(){ return value; }
	public void setValue(T val) { value = val; }
	public boolean hasNext() { return next != null; }
	public Node<T> getNext() { return next; }
	public void setNext(Node<T> node) { next = node; }
}
